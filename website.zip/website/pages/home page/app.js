document.querySelector(".r-btn").addEventListener("click",{
    function (event) {
        document.querySelector(".product-slide").scrollLeft +=1100;
        event.preventDefault();
        
    }
});